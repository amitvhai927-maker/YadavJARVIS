# Yadav JARVIS v1

Android Studio Kotlin starter project.

## Included
- Futuristic JARVIS UI
- Voice recognition
- Text-to-speech
- Runtime microphone permission
- Open WhatsApp / YouTube / Chrome / Settings
- Confirmation dialog for call, WhatsApp-message and payment intents
- Safe payment placeholder: no silent transfer

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Connect an Android phone with USB debugging enabled.
4. Run the `app` configuration.
5. Grant microphone permission.

## Important
This starter intentionally does not perform silent financial transfers or bypass WhatsApp/Android security. Payment should use the official provider SDK/deep-link flow and require final user confirmation.

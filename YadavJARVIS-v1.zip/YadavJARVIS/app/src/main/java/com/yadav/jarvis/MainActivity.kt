package com.yadav.jarvis

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var voice: VoiceManager
    private lateinit var engine: JarvisEngine
    private lateinit var tts: TextToSpeech
    private lateinit var response: TextView
    private lateinit var status: TextView
    private lateinit var input: EditText

    private val micPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) voice.start() else show("Microphone permission is required.")
    }

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        setContentView(R.layout.activity_main)
        response = findViewById(R.id.responseText)
        status = findViewById(R.id.statusText)
        input = findViewById(R.id.commandInput)
        val send: Button = findViewById(R.id.sendButton)
        val mic: Button = findViewById(R.id.micButton)

        tts = TextToSpeech(this) { if (it == TextToSpeech.SUCCESS) tts.language = Locale.US }
        voice = VoiceManager(this) { text -> runOnUiThread { input.setText(text); execute(text) } }
        engine = JarvisEngine(this, { msg -> runOnUiThread { show(msg); speak(msg) } },
            { question, action ->
                runOnUiThread {
                    AlertDialog.Builder(this).setTitle("JARVIS Confirmation")
                        .setMessage(question)
                        .setNegativeButton("Cancel", null)
                        .setPositiveButton("Confirm") { _, _ -> action() }
                        .show()
                }
            })

        send.setOnClickListener { input.text.toString().takeIf { it.isNotBlank() }?.let(::execute) }
        mic.setOnClickListener {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) voice.start()
            else micPermission.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun execute(c: String) { status.text = "PROCESSING..."; engine.execute(c) }
    private fun show(s: String) { response.text = s; status.text = "ONLINE" }
    private fun speak(s: String) { tts.speak(s, TextToSpeech.QUEUE_FLUSH, null, "jarvis") }
    override fun onDestroy() { voice.destroy(); tts.shutdown(); super.onDestroy() }
}
package com.yadav.jarvis

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

class VoiceManager(private val context: Context, private val onResult: (String)->Unit) {
    private var recognizer: SpeechRecognizer? = null
    fun start() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onResult("Voice recognition is unavailable."); return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(context)
        recognizer!!.setRecognitionListener(object: RecognitionListener {
            override fun onResults(b: Bundle?) {
                val r = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (!r.isNullOrEmpty()) onResult(r[0])
            }
            override fun onError(error: Int) { onResult("I could not understand that.") }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(t: Int, b: Bundle?) {}
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
        recognizer!!.startListening(i)
    }
    fun destroy() { recognizer?.destroy(); recognizer = null }
}
package com.yadav.jarvis

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings

class JarvisEngine(private val context: Context, private val reply: (String)->Unit,
                   private val confirm: (String, ()->Unit)->Unit) {

    fun execute(command: String) {
        val t = command.trim().lowercase()
        when {
            t == "open whatsapp" || t.contains("whatsapp kholo") || t.contains("open whatsapp") -> openPackage("com.whatsapp", "WhatsApp")
            t.contains("open youtube") -> openPackage("com.google.android.youtube", "YouTube")
            t.contains("open chrome") -> openPackage("com.android.chrome", "Chrome")
            t.contains("settings") -> { context.startActivity(Intent(Settings.ACTION_SETTINGS)); reply("Opening settings.") }
            t.startsWith("call ") || t.startsWith("phone ") -> {
                val name = command.substringAfter(" ").trim()
                confirm("Call $name?") { reply("Call action approved. Contact picker is the next extension.") }
            }
            t.contains("whatsapp") && (t.contains("message") || t.contains("msg")) -> {
                confirm("Open WhatsApp to send this message?") { openPackage("com.whatsapp", "WhatsApp") }
            }
            t.contains("payment") || t.contains("pay ") || t.contains("paisa") || t.contains("rupaye") -> {
                confirm("Payment request detected. Open the payment app for final user confirmation?") {
                    reply("Payment app integration is intentionally kept confirmation-based. Add your authorized provider flow in Part 2.")
                }
            }
            else -> reply("I heard: $command. I don't have that action yet.")
        }
    }

    private fun openPackage(pkg: String, name: String) {
        val i = context.packageManager.getLaunchIntentForPackage(pkg)
        if (i == null) reply("$name is not installed.")
        else { context.startActivity(i); reply("Opening $name.") }
    }
}